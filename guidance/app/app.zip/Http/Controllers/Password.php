<?php

namespace App\Http\Controllers;

interface Password
{
    public function update () ;
}

