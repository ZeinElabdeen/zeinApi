<?php

namespace App\Http\Controllers\Api\Order;

use App\Http\Controllers\ResponseController;
use App\Http\Resources\RoomContentCollection;
use App\Models\Message;
use App\Models\Order;
use App\Models\Room;
use App\Models\User;


class OrderMessagesController extends ResponseController
{

    public function orderRoomMessages ($orderId) {
        $order_messages = Order::findOrFail($orderId);
      //  $order_messages = Order::findOrFail($orderId)->room->messages;
        if($order_messages->status == '0')
        {
          return response()->json(['message' => trans('response.order_not_confirmed')],444);
        }else{
          return response()->json(['data'=> new RoomContentCollection($order_messages->room->messages)]);
        }
    }

    private function checkRoomExist ($orderId) {
        $checkRoom = Room::first();

        return ($checkRoom == null) ? $this->createRoom($receiverId) : $checkRoom->id;
    }

}
